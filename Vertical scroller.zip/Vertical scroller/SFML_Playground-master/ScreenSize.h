#pragma once

struct ScreenSize
{
public:
	static const int s_width{ 800 };

	static const int s_height{ 600 };
};
