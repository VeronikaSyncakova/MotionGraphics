#pragma once
#include <SFML/Graphics.hpp>
#include<cstdlib>
#include<ctime>

int const PLAYER_SPEED = 2;
int const GHOST_SPEED = 1;
int const FOOD_SPACE = 55;
float const BODY_WIDTH = 40.0f;
float const BODY_HEIGHT = 60.0f;